
This demo was originally released by Bookworm somewhere around 2011.
I have not been able to find the original publication link.

The method used for playing samples triggers a bug that creates permanent spikes on GBA, which is what I fixed.
I do not claim to be the author of this demo. The original source can be found in the src folder, whereas the updated source can be found in the fixed_src folder.
