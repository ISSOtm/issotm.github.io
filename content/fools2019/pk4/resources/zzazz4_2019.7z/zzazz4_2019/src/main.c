


// where the instructions write to, pointers
#define  WRITE_WORD_PTR 0xAEF5 // 2b
#define  WRITE_LONG_PTR 0xAFE5 // 4b
#define  WRITE_BYTE_PTR 0xAF0B // 1b
// dunno
#define  ADDRESS_BUFFER1 0xAF1B // 2b
#define  COPY_BYTE_SIDE_EFFECT 0xAF31 // 2b
#define  COPY_BYTE_PTR 0xAF31 // 1b



int main() {

    void *gimme = malloc(-1);

    return 0;
}
