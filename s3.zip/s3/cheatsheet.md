# HEX.py

HEX: data_len, addr(16BE), type, data, checksum

/!\\ Utiliser `_hex`, pas `hex`

## Patch du firmware

https://en.wikipedia.org/wiki/Intel_HEX

HEXFile(filename) .dump_to(filename)
                  .to_hex(base_addr) adresse où commence le programme
				                     si les paquets sont ordonnés, celle du premier

find_strings(data, min_len, filter) data = blob à chercher, longueur minimale, filtre supplémentaire (par caractère)
Exemple : find_strings(HEXFile("secure_firmware.hex").to_hex(0x4000), 8, lambda c: chr(c) in "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ")

HEXLine(string) .patch(string, start) pour modifier les données, puis
                .correct_sum()        pour corriger la checksum

## Utilisation tcpdump

ifconfig pour récupérer l'interface sur laquelle dumper

`tcpdump -A -i <interface> port 1337` (-A pour print les paquets)