rgbasm -o APPLE.o APPLE.z80
rgblink -n APPLE.sym -o APPLE.gbc APPLE.o
rm APPLE.o

truncate --size 16k APPLE.gbc
cat APPLE.gbc tile_n.bin map_n.bin dummy00.bin BA_4bit8kmono.bin > BADAPPLE.GBC
rgbfix -p 0 -v BADAPPLE.GBC
rm APPLE.gbc
