
import string


def _hex(x):
    return hex(x)[2:].zfill(2)

def is_printable(byte):
    return chr(byte) in string.printable[:-5]

def char_or_placeholder(byte):
    return chr(byte) if is_printable(byte) else "."


def hex2bin(filename, start_addr):
    return HEXFile(filename).to_bin(start_addr)

def find_strings(data, min_len, filter=is_printable):
    strings = []
    string = []
    for byte in data:
        if filter(byte):
            string.append(chr(byte))
        elif len(string) > 0:
            if len(string) >= min_len:
                strings.append("".join(string))
            string = []
    return strings

"""
Turns a string into its Intel HEX representation
"""
def hexformat(string):
    return "".join(map(lambda c: _hex(ord(c)), string))


class HEXLine:
    def __init__(self, string):
        assert string[0] == ':'
        position = 1
        def get_int(len):
            nonlocal position
            position += len
            return int(string[position-len:position], 16)
        self.size = get_int(2)
        self.addr = get_int(4)
        self.type = get_int(2)
        self.data = [ get_int(2) for _ in range(self.size) ]
        self.checksum = get_int(2)

    """
Patch the line's contents to contain a certain string starting at a certain offset
    """
    def patch(self, string, start):
        assert len(string) % 2 == 0
        for i in range(len(string) // 2):
            self.data[i+start] = int(string[i*2:i*2+2], 16)
        return self

    def correct_sum(self):
        self.checksum = self.compute_checksum()
        return self

    def compute_checksum(self):
        return -sum([self.size, self.addr // 256, self.addr % 256, self.type] + self.data) % 256

    def get_raw_string(self):
        return f":{_hex(self.size)}{_hex(self.addr)}{_hex(self.type)}{''.join([_hex(x) for x in self.data])}{_hex(self.checksum)}"

    def ascii_dump(self):
        return "".join(map(char_or_placeholder, self.data))

    def __repr__(self):
        return f"{self.get_raw_string()} ~ {self.ascii_dump()}"


class HEXFile:
    def __init__(self, filename):
        with open(filename, "rt") as file:
            self.lines = [ HEXLine(line) for line in file ]

    def dump_to(self, filename):
        with open(filename, "wt") as output:
            output.writelines([ f"{line.__repr__()}\n" for line in self.lines ])

    def to_bin(self, base_addr):
        data = []
        for line in self.lines:
            if line.type == 0:
                start_addr = line.addr - base_addr
                end_addr = start_addr + line.size
                if len(data) < start_addr:
                    data.extend([0] * (end_addr - len(data)))
                data[start_addr:end_addr] = line.data
        return data

    def __repr__(self):
        return "\n".join(map(HEXLine.__repr__(), self.lines))
